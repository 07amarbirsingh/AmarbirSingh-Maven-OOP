package org.example;
public class TotalSweet {
    Chocolate chocolate;
    OtherSweets otherSweets;

}